The profiling results for PRISM cohort can be found in "Abd Table".
The BC distance matrix named as "dist_XX.dist" are used as input for R code "Fig6a.R" to draw the PCoA plot.
The "beta.sh" recorded the commandlines for PERMANOVA test.
For MiMeNet and mNODE please refer to "Fig6bcd".